<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h1>{{ $title }}</h1>
    <p>{{ $body }}</p>
</body>
</html>
